import { redirect } from "react-router-dom";

function Welcome(){

    
        setTimeout(()=>redirect('/'),1000)

    return(
        <div>
            <h1>Login Successful</h1>
            <h3>You will be redirected to home page</h3>
        </div>
    )
}

export default Welcome;